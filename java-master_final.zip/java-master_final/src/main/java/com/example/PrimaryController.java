package com.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class PrimaryController {
    private boolean isEditing = false;
    private HelpDeskTicket selectedTicket;
    @FXML
    private TextField f1;

    @FXML
    private TextField f2;

    @FXML
    private RadioButton rbCategoriaComputador;

    @FXML
    private RadioButton rbCategoriaImpressora;

    @FXML
    private RadioButton rbCategoriaRede;

    @FXML
    private RadioButton rbAtividadePrimeiroContato;

    @FXML
    private RadioButton rbAtividadeAtendido;

    @FXML
    private RadioButton rbAtividadeEncerrado;

    @FXML
    private ListView<HelpDeskTicket> chamadosListView;

    private ObservableList<HelpDeskTicket> tickets = FXCollections.observableArrayList();

    private ToggleGroup categoriaToggleGroup = new ToggleGroup();
    private ToggleGroup atividadeToggleGroup = new ToggleGroup();

    public void initialize() {
        rbCategoriaComputador.setToggleGroup(categoriaToggleGroup);
        rbCategoriaImpressora.setToggleGroup(categoriaToggleGroup);
        rbCategoriaRede.setToggleGroup(categoriaToggleGroup);

        rbAtividadePrimeiroContato.setToggleGroup(atividadeToggleGroup);
        rbAtividadeAtendido.setToggleGroup(atividadeToggleGroup);
        rbAtividadeEncerrado.setToggleGroup(atividadeToggleGroup);

        chamadosListView.setItems(tickets);
    }

    public void confirmar() {
        String userName = f1.getText();
        String equipmentCode = f2.getText();
        String category = "";
        if (rbCategoriaComputador.isSelected()) {
            category = "Computador";
        } else if (rbCategoriaImpressora.isSelected()) {
            category = "Impressora";
        } else if (rbCategoriaRede.isSelected()) {
            category = "Rede";
        }

        String activity = "";
        if (rbAtividadePrimeiroContato.isSelected()) {
            activity = "Primeiro Contato";
        } else if (rbAtividadeAtendido.isSelected()) {
            activity = "Atendido";
        } else if (rbAtividadeEncerrado.isSelected()) {
            activity = "Encerrado";
        }

        if (isEditing) {
            // Atualiza as informações do ticket em edição
            selectedTicket.setUserName(userName);
            selectedTicket.setEquipmentCode(equipmentCode);
            selectedTicket.setCategory(category);
            selectedTicket.setActivity(activity);
            isEditing = false;
        } else {
            // Cria um novo ticket
            HelpDeskTicket ticket = new HelpDeskTicket(userName, equipmentCode, category, activity);
            tickets.add(ticket);
        }

        // Atualiza a exibição da ListView
        chamadosListView.refresh();
        clearFieldsAndRadioButtons();
    }
    public void remover() {
        if (selectedTicket != null) {
            tickets.remove(selectedTicket);
            updateTicketsTextArea();
            selectedTicket = null;
        }
    }

    public void selecionar() {
        selectedTicket = chamadosListView.getSelectionModel().getSelectedItem();
        if (selectedTicket != null) {
            f1.setText(selectedTicket.getUserName());
            f2.setText(selectedTicket.getEquipmentCode());

            switch (selectedTicket.getCategory()) {
                case "Computador":
                    rbCategoriaComputador.setSelected(true);
                    break;
                case "Impressora":
                    rbCategoriaImpressora.setSelected(true);
                    break;
                case "Rede":
                    rbCategoriaRede.setSelected(true);
                    break;
            }

            switch (selectedTicket.getActivity()) {
                case "Primeiro Contato":
                    rbAtividadePrimeiroContato.setSelected(true);
                    break;
                case "Atendido":
                    rbAtividadeAtendido.setSelected(true);
                    break;
                case "Encerrado":
                    rbAtividadeEncerrado.setSelected(true);
                    break;
            }
        }
    }

   public void alterar() {
        int selectedIndex = chamadosListView.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            selectedTicket = tickets.get(selectedIndex);
            isEditing = true;

            // Preenche os campos com as informações do ticket selecionado
            f1.setText(selectedTicket.getUserName());
            f2.setText(selectedTicket.getEquipmentCode());

            switch (selectedTicket.getCategory()) {
                case "Computador":
                    rbCategoriaComputador.setSelected(true);
                    break;
                case "Impressora":
                    rbCategoriaImpressora.setSelected(true);
                    break;
                case "Rede":
                    rbCategoriaRede.setSelected(true);
                    break;
            }

            switch (selectedTicket.getActivity()) {
                case "Primeiro Contato":
                    rbAtividadePrimeiroContato.setSelected(true);
                    break;
                case "Atendido":
                    rbAtividadeAtendido.setSelected(true);
                    break;
                case "Encerrado":
                    rbAtividadeEncerrado.setSelected(true);
                    break;
            }
        }
    }



    private void updateTicketsTextArea() {
        StringBuilder sb = new StringBuilder();

        for (HelpDeskTicket ticket : tickets) {
            sb.append("Usuário: ").append(ticket.getUserName())
                    .append(", Equipamento: ").append(ticket.getEquipmentCode())
                    .append(", Categoria: ").append(ticket.getCategory())
                    .append(", Atividade: ").append(ticket.getActivity())
                    .append("\n");
        }

    }

    private void clearFieldsAndRadioButtons() {
        f1.clear();
        f2.clear();

        categoriaToggleGroup.selectToggle(null);
        atividadeToggleGroup.selectToggle(null);
    }
}
